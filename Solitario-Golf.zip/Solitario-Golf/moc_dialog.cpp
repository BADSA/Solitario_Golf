/****************************************************************************
** Meta object code from reading C++ file 'dialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Solitario-Golf/dialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Dialog_t {
    QByteArrayData data[64];
    char stringdata[912];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_Dialog_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_Dialog_t qt_meta_stringdata_Dialog = {
    {
QT_MOC_LITERAL(0, 0, 6),
QT_MOC_LITERAL(1, 7, 14),
QT_MOC_LITERAL(2, 22, 0),
QT_MOC_LITERAL(3, 23, 14),
QT_MOC_LITERAL(4, 38, 14),
QT_MOC_LITERAL(5, 53, 14),
QT_MOC_LITERAL(6, 68, 14),
QT_MOC_LITERAL(7, 83, 14),
QT_MOC_LITERAL(8, 98, 14),
QT_MOC_LITERAL(9, 113, 14),
QT_MOC_LITERAL(10, 128, 14),
QT_MOC_LITERAL(11, 143, 14),
QT_MOC_LITERAL(12, 158, 14),
QT_MOC_LITERAL(13, 173, 14),
QT_MOC_LITERAL(14, 188, 14),
QT_MOC_LITERAL(15, 203, 14),
QT_MOC_LITERAL(16, 218, 14),
QT_MOC_LITERAL(17, 233, 14),
QT_MOC_LITERAL(18, 248, 14),
QT_MOC_LITERAL(19, 263, 14),
QT_MOC_LITERAL(20, 278, 14),
QT_MOC_LITERAL(21, 293, 14),
QT_MOC_LITERAL(22, 308, 14),
QT_MOC_LITERAL(23, 323, 14),
QT_MOC_LITERAL(24, 338, 14),
QT_MOC_LITERAL(25, 353, 14),
QT_MOC_LITERAL(26, 368, 14),
QT_MOC_LITERAL(27, 383, 14),
QT_MOC_LITERAL(28, 398, 14),
QT_MOC_LITERAL(29, 413, 14),
QT_MOC_LITERAL(30, 428, 14),
QT_MOC_LITERAL(31, 443, 14),
QT_MOC_LITERAL(32, 458, 13),
QT_MOC_LITERAL(33, 472, 13),
QT_MOC_LITERAL(34, 486, 13),
QT_MOC_LITERAL(35, 500, 13),
QT_MOC_LITERAL(36, 514, 13),
QT_MOC_LITERAL(37, 528, 13),
QT_MOC_LITERAL(38, 542, 13),
QT_MOC_LITERAL(39, 556, 13),
QT_MOC_LITERAL(40, 570, 13),
QT_MOC_LITERAL(41, 584, 14),
QT_MOC_LITERAL(42, 599, 14),
QT_MOC_LITERAL(43, 614, 14),
QT_MOC_LITERAL(44, 629, 14),
QT_MOC_LITERAL(45, 644, 14),
QT_MOC_LITERAL(46, 659, 14),
QT_MOC_LITERAL(47, 674, 14),
QT_MOC_LITERAL(48, 689, 14),
QT_MOC_LITERAL(49, 704, 14),
QT_MOC_LITERAL(50, 719, 14),
QT_MOC_LITERAL(51, 734, 14),
QT_MOC_LITERAL(52, 749, 14),
QT_MOC_LITERAL(53, 764, 14),
QT_MOC_LITERAL(54, 779, 11),
QT_MOC_LITERAL(55, 791, 13),
QT_MOC_LITERAL(56, 805, 13),
QT_MOC_LITERAL(57, 819, 13),
QT_MOC_LITERAL(58, 833, 13),
QT_MOC_LITERAL(59, 847, 13),
QT_MOC_LITERAL(60, 861, 13),
QT_MOC_LITERAL(61, 875, 9),
QT_MOC_LITERAL(62, 885, 8),
QT_MOC_LITERAL(63, 894, 16)
    },
    "Dialog\0on_b50_clicked\0\0on_b51_clicked\0"
    "on_b52_clicked\0on_b53_clicked\0"
    "on_b54_clicked\0on_b40_clicked\0"
    "on_b41_clicked\0on_b42_clicked\0"
    "on_b43_clicked\0on_b44_clicked\0"
    "on_b30_clicked\0on_b31_clicked\0"
    "on_b32_clicked\0on_b33_clicked\0"
    "on_b34_clicked\0on_b20_clicked\0"
    "on_b21_clicked\0on_b22_clicked\0"
    "on_b23_clicked\0on_b24_clicked\0"
    "on_b10_clicked\0on_b11_clicked\0"
    "on_b12_clicked\0on_b13_clicked\0"
    "on_b14_clicked\0on_b00_clicked\0"
    "on_b01_clicked\0on_b02_clicked\0"
    "on_b03_clicked\0on_b04_clicked\0"
    "on_m1_clicked\0on_m2_clicked\0on_m3_clicked\0"
    "on_m4_clicked\0on_m5_clicked\0on_m6_clicked\0"
    "on_m7_clicked\0on_m8_clicked\0on_m9_clicked\0"
    "on_m10_clicked\0on_m11_clicked\0"
    "on_m12_clicked\0on_m13_clicked\0"
    "on_m14_clicked\0on_m15_clicked\0"
    "on_m16_clicked\0on_m17_clicked\0"
    "on_m18_clicked\0on_m19_clicked\0"
    "on_m20_clicked\0on_m21_clicked\0"
    "on_m22_clicked\0revisaJuego\0revisaJugada1\0"
    "revisaJugada2\0revisaJugada3\0revisaJugada4\0"
    "revisaJugada5\0revisaJugada6\0sumaFilas\0"
    "finJuego\0on_leave_clicked\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Dialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      62,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  324,    2, 0x08,
       3,    0,  325,    2, 0x08,
       4,    0,  326,    2, 0x08,
       5,    0,  327,    2, 0x08,
       6,    0,  328,    2, 0x08,
       7,    0,  329,    2, 0x08,
       8,    0,  330,    2, 0x08,
       9,    0,  331,    2, 0x08,
      10,    0,  332,    2, 0x08,
      11,    0,  333,    2, 0x08,
      12,    0,  334,    2, 0x08,
      13,    0,  335,    2, 0x08,
      14,    0,  336,    2, 0x08,
      15,    0,  337,    2, 0x08,
      16,    0,  338,    2, 0x08,
      17,    0,  339,    2, 0x08,
      18,    0,  340,    2, 0x08,
      19,    0,  341,    2, 0x08,
      20,    0,  342,    2, 0x08,
      21,    0,  343,    2, 0x08,
      22,    0,  344,    2, 0x08,
      23,    0,  345,    2, 0x08,
      24,    0,  346,    2, 0x08,
      25,    0,  347,    2, 0x08,
      26,    0,  348,    2, 0x08,
      27,    0,  349,    2, 0x08,
      28,    0,  350,    2, 0x08,
      29,    0,  351,    2, 0x08,
      30,    0,  352,    2, 0x08,
      31,    0,  353,    2, 0x08,
      32,    0,  354,    2, 0x08,
      33,    0,  355,    2, 0x08,
      34,    0,  356,    2, 0x08,
      35,    0,  357,    2, 0x08,
      36,    0,  358,    2, 0x08,
      37,    0,  359,    2, 0x08,
      38,    0,  360,    2, 0x08,
      39,    0,  361,    2, 0x08,
      40,    0,  362,    2, 0x08,
      41,    0,  363,    2, 0x08,
      42,    0,  364,    2, 0x08,
      43,    0,  365,    2, 0x08,
      44,    0,  366,    2, 0x08,
      45,    0,  367,    2, 0x08,
      46,    0,  368,    2, 0x08,
      47,    0,  369,    2, 0x08,
      48,    0,  370,    2, 0x08,
      49,    0,  371,    2, 0x08,
      50,    0,  372,    2, 0x08,
      51,    0,  373,    2, 0x08,
      52,    0,  374,    2, 0x08,
      53,    0,  375,    2, 0x08,
      54,    0,  376,    2, 0x08,
      55,    0,  377,    2, 0x08,
      56,    0,  378,    2, 0x08,
      57,    0,  379,    2, 0x08,
      58,    0,  380,    2, 0x08,
      59,    0,  381,    2, 0x08,
      60,    0,  382,    2, 0x08,
      61,    0,  383,    2, 0x08,
      62,    0,  384,    2, 0x08,
      63,    0,  385,    2, 0x08,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Int,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Dialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Dialog *_t = static_cast<Dialog *>(_o);
        switch (_id) {
        case 0: _t->on_b50_clicked(); break;
        case 1: _t->on_b51_clicked(); break;
        case 2: _t->on_b52_clicked(); break;
        case 3: _t->on_b53_clicked(); break;
        case 4: _t->on_b54_clicked(); break;
        case 5: _t->on_b40_clicked(); break;
        case 6: _t->on_b41_clicked(); break;
        case 7: _t->on_b42_clicked(); break;
        case 8: _t->on_b43_clicked(); break;
        case 9: _t->on_b44_clicked(); break;
        case 10: _t->on_b30_clicked(); break;
        case 11: _t->on_b31_clicked(); break;
        case 12: _t->on_b32_clicked(); break;
        case 13: _t->on_b33_clicked(); break;
        case 14: _t->on_b34_clicked(); break;
        case 15: _t->on_b20_clicked(); break;
        case 16: _t->on_b21_clicked(); break;
        case 17: _t->on_b22_clicked(); break;
        case 18: _t->on_b23_clicked(); break;
        case 19: _t->on_b24_clicked(); break;
        case 20: _t->on_b10_clicked(); break;
        case 21: _t->on_b11_clicked(); break;
        case 22: _t->on_b12_clicked(); break;
        case 23: _t->on_b13_clicked(); break;
        case 24: _t->on_b14_clicked(); break;
        case 25: _t->on_b00_clicked(); break;
        case 26: _t->on_b01_clicked(); break;
        case 27: _t->on_b02_clicked(); break;
        case 28: _t->on_b03_clicked(); break;
        case 29: _t->on_b04_clicked(); break;
        case 30: _t->on_m1_clicked(); break;
        case 31: _t->on_m2_clicked(); break;
        case 32: _t->on_m3_clicked(); break;
        case 33: _t->on_m4_clicked(); break;
        case 34: _t->on_m5_clicked(); break;
        case 35: _t->on_m6_clicked(); break;
        case 36: _t->on_m7_clicked(); break;
        case 37: _t->on_m8_clicked(); break;
        case 38: _t->on_m9_clicked(); break;
        case 39: _t->on_m10_clicked(); break;
        case 40: _t->on_m11_clicked(); break;
        case 41: _t->on_m12_clicked(); break;
        case 42: _t->on_m13_clicked(); break;
        case 43: _t->on_m14_clicked(); break;
        case 44: _t->on_m15_clicked(); break;
        case 45: _t->on_m16_clicked(); break;
        case 46: _t->on_m17_clicked(); break;
        case 47: _t->on_m18_clicked(); break;
        case 48: _t->on_m19_clicked(); break;
        case 49: _t->on_m20_clicked(); break;
        case 50: _t->on_m21_clicked(); break;
        case 51: _t->on_m22_clicked(); break;
        case 52: { bool _r = _t->revisaJuego();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 53: { bool _r = _t->revisaJugada1();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 54: { bool _r = _t->revisaJugada2();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 55: { bool _r = _t->revisaJugada3();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 56: { bool _r = _t->revisaJugada4();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 57: { bool _r = _t->revisaJugada5();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 58: { bool _r = _t->revisaJugada6();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 59: { int _r = _t->sumaFilas();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 60: _t->finJuego(); break;
        case 61: _t->on_leave_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject Dialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_Dialog.data,
      qt_meta_data_Dialog,  qt_static_metacall, 0, 0}
};


const QMetaObject *Dialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Dialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Dialog.stringdata))
        return static_cast<void*>(const_cast< Dialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int Dialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 62)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 62;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 62)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 62;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
